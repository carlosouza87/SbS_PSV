% clear all;close all;clc
% clear variables;close all;clc

caseid = 'conjunto'

rho = 1025;
ULEN = 1;

T_gdf = [1 -1 -1];
Tscale = diag([T_gdf T_gdf]);

inpt1 = [caseid '.1'];
[periods,dof_i,dof_j,A,B] = textread(inpt1);

Nperiods = length(periods); % Number of periods, considering repeated
unique_periods = unique(periods); % 

% Extract added mass and damping
for p = 1:Nperiods
    idx = find(unique_periods == periods(p));
    Aij(dof_i(p),dof_j(p),idx) = A(p);
    Bij(dof_i(p),dof_j(p),idx) = B(p);
end

omg = (2*pi./unique_periods)'; % "Omega" array, for frequency in rad/s

% Sort with respect to frequency in increasing order
[omg_sorted, omg_idx] = sort(omg);
Aij_sorted = Aij(:,:,omg_idx);
Bij_sorted = Bij(:,:,omg_idx);

% Set the lowest available frequency to 0 rad/s and the highest as 10 rad/s, corresponding to 
% the assymptotic infinite frequency.
omg = [0 omg_sorted 10]; 
Nomg = length(omg);

A11 = zeros(6,6,Nomg);
A11(:,:,2:Nomg-1) = Aij_sorted(1:6,1:6,:);
A12 = zeros(6,6,Nomg);
A12(:,:,2:Nomg-1) = Aij_sorted(1:6,7:12,:);
A21 = zeros(6,6,Nomg);
A21(:,:,2:Nomg-1) = Aij_sorted(7:12,1:6,:);
A22 = zeros(6,6,Nomg);
A22(:,:,2:Nomg-1) = Aij_sorted(7:12,7:12,:);

B11 = zeros(6,6,Nomg);
B11(:,:,2:Nomg-1) = Bij_sorted(1:6,1:6,:);
B12 = zeros(6,6,Nomg);
B12(:,:,2:Nomg-1) = Bij_sorted(1:6,7:12,:);
B21 = zeros(6,6,Nomg);
B21(:,:,2:Nomg-1)= Bij_sorted(7:12,1:6,:);
B22 = zeros(6,6,Nomg);
B22(:,:,2:Nomg-1)= Bij_sorted(7:12,7:12,:);

% Define the added mass for omg = 0 rad/s equal to the first value provided by WAMIT
A11(:,:,1) = A11(:,:,2);
A12(:,:,1) = A12(:,:,2);
A21(:,:,1) = A21(:,:,2);
A22(:,:,1) = A22(:,:,2);

% Define the added mass for omg = 10 rad/s equal to the last value (highest frequency)
A11(:,:,Nomg) = A11(:,:,Nomg-1);
A12(:,:,Nomg) = A12(:,:,Nomg-1);
A21(:,:,Nomg) = A21(:,:,Nomg-1);
A22(:,:,Nomg) = A22(:,:,Nomg-1);

% Define the radiation damping for omg = 0 rad/s and for omg = 10 rad/s equal to zero
B11(:,:,1) = 0;
B12(:,:,1) = 0;
B21(:,:,1) = 0;
B22(:,:,1) = 0;
B11(:,:,Nomg) = 0;
B12(:,:,Nomg) = 0;
B21(:,:,Nomg) = 0;
B22(:,:,Nomg) = 0;


% Scaling of added mass and damping matrices (p. 4-3 of Wamit manual v. 6.2s)
% Aij = Aij' * rho * ULEN^k
% Bij = Bij' * rho * w * ULEN^k
% where k=3 for i,j=1,2,3, k=5 for i,j=1,2,3, k = 4 otherwise.
scaleA  = [ ones(3)*3 ones(3)*4
    ones(3)*4 ones(3)*5 ];

for w = 1:Nomg
    % scale Wamit data to SI system (Wamit axes)
    A11_dim = A11(:,:,w)*rho .* (ULEN .^ scaleA);
    A12_dim = A12(:,:,w)*rho .* (ULEN .^ scaleA);
    A21_dim = A21(:,:,w)*rho .* (ULEN .^ scaleA);
    A22_dim = A22(:,:,w)*rho .* (ULEN .^ scaleA);
    B11_dim = B11(:,:,w)*rho .* omg(w) ...
        .* (ULEN .^ scaleA);
    B12_dim = B12(:,:,w)*rho .* omg(w) ...
        .* (ULEN .^ scaleA);
    B21_dim = B21(:,:,w)*rho .* omg(w) ...
        .* (ULEN .^ scaleA);
    B22_dim = B22(:,:,w)*rho .* omg(w) ...
        .* (ULEN .^ scaleA);
    % transform to Fossen axes
    A11(:,:,w) = Tscale*A11_dim*Tscale;
    A12(:,:,w) = Tscale*A12_dim*Tscale;
    A21(:,:,w) = Tscale*A21_dim*Tscale;
    A22(:,:,w) = Tscale*A22_dim*Tscale;
    B11(:,:,w) = Tscale*B11_dim*Tscale;
    B12(:,:,w) = Tscale*B12_dim*Tscale;
    B21(:,:,w) = Tscale*B21_dim*Tscale;
    B22(:,:,w) = Tscale*B22_dim*Tscale;
end

% Colocar um if aqui, e ativar apenas se o usu�rio quiser. Incluir fun��o
% do andrey




% save memory_ss A11 A12 A21 A22 B11 B12 B21 B22 omg dof_unst11 dof_unst12 dof_unst21 dof_unst22

% clear all
